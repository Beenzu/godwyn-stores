# Godwyn Stores — low-cost production version

Godwyn Stores is a lightweight Node.js/Express online store with a customer storefront, stock panel, order management and CRM.

## Improvements in this version

- **Persistent storage:** `data.json` and uploaded product photos can live on a Render/Railway persistent disk using `DATA_DIR`.
- **Product photos:** upload JPG/PNG/WEBP/GIF images (up to 5 MB) from the admin panel, or use an image URL.
- **WhatsApp:** customers get a WhatsApp confirmation button after ordering. Default business WhatsApp: 0760565047.
- **Zambian currency:** default currency is ZMW and store contact details are preconfigured.
- **Business contact:** 0760565047 and WhatsApp are shown on the storefront.
- **Security:** Helmet security headers, login/setup rate limits, order rate limits, stronger 10+ character admin passwords, private setup key, HTTP-only session cookie and production `secure` cookies.
- **Custom domain ready:** after deployment, connect your own domain in the hosting provider and point it to the provider's service. No code change is required.

## Local setup

Requires Node.js 18+.

```bash
npm install
cp .env.example .env
```

Create strong values for `JWT_SECRET` and `SETUP_KEY`.

Example:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Then:

```bash
npm start
```

Open `http://localhost:3000`.

The first admin setup now requires the private `SETUP_KEY` from `.env`.

## Recommended near-free deployment: Render

1. Put this folder in a GitHub repository.
2. In Render, create a **Web Service** from the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Set environment variables:
   - `NODE_ENV=production`
   - `JWT_SECRET=<strong random secret>`
   - `SETUP_KEY=<private setup key>`
   - `DATA_DIR=/var/data`
   - `UPLOAD_DIR=/var/data/uploads`
6. Add a persistent disk mounted at `/var/data`.
7. Deploy.
8. Open the generated Render URL and use **Store login** to create the admin account with the same `SETUP_KEY`.

### Custom domain

When the store is working, buy a domain from a registrar of your choice (for example `godwynstores.com` if available), then use Render's **Custom Domains** section. Render will show the DNS records you need to add at the registrar. HTTPS is then handled by the hosting provider.

## Important production notes

- Never commit `.env` or real secrets to GitHub.
- Keep the `SETUP_KEY` private. It is only needed once to create the first admin account.
- The persistent disk is important because this version stores orders, customers, stock and uploaded photos on disk.
- Keep backups of `data.json`.
- For a larger store or multiple server instances, migrate the datastore to Postgres/Supabase.
- For online mobile-money/card payments, add a Zambia-compatible payment gateway later rather than storing card details yourself.


Deployment note: the frontend uses inline event handlers, so Helmet CSP is disabled while other Helmet security protections remain enabled.
